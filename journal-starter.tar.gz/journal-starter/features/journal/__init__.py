"""Функциональный срез Журнал."""

from flask import Blueprint

bp = Blueprint(
    "journal",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/features/journal/static",
)

from . import api, pages  # noqa: E402,F401
