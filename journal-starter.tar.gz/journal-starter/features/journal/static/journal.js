import {requestJSON} from "/static/js/api.js";
import {message, busy, fillGroups} from "/static/js/ui.js";
const API = "/api/journal";
const groupSelect = document.querySelector("#group-select");
const head = document.querySelector("#table-head");
const body = document.querySelector("#table-body");
const MARKS = [5, 4, 3, 2];
let journal = null, groups = [], loaded = false;

/** Выставляет или изменяет оценку пары студент и предмет. */
async function saveGrade(studentId, subjectId, mark) {
  return requestJSON(API + "/grades", "POST", {
    student_id: studentId, subject_id: subjectId, mark: mark,
  });
}

/** Удаляет оценку пары студент и предмет. */
async function deleteGrade(studentId, subjectId) {
  return requestJSON(API + "/grades/" + studentId + "/" + subjectId, "DELETE");
}

/** Возвращает оценку для ячейки или null, если строки нет. */
function findMark(studentId, subjectId) {
  const record = journal.grades.find(function(row) {
    return row.student_id === studentId && row.subject_id === subjectId;
  });
  return record ? record.mark : null;
}

/** Строит шапку и тело таблицы журнала. */
function render() {
  head.replaceChildren();
  const headerRow = document.createElement("tr");
  const nameHead = document.createElement("th"); nameHead.textContent = "Студент"; headerRow.append(nameHead);
  for (const subject of journal.subjects) {
    const th = document.createElement("th"); th.textContent = subject.name;
    th.className = "grade-cell"; headerRow.append(th);
  }
  head.append(headerRow);
  body.replaceChildren();
  if (!journal.students.length) {
    const row = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = journal.subjects.length + 1;
    td.className = "empty-row"; td.textContent = "В группе нет студентов";
    row.append(td); body.append(row); return;
  }
  for (const student of journal.students) {
    const row = document.createElement("tr");
    const nameCell = document.createElement("td"); nameCell.textContent = student.name; row.append(nameCell);
    for (const subject of journal.subjects) {
      const td = document.createElement("td"); td.className = "grade-cell";
      const button = document.createElement("button"); button.type = "button"; button.className = "grade-button";
      button.dataset.action = "mark"; button.dataset.student = String(student.id); button.dataset.subject = String(subject.id);
      const mark = findMark(student.id, subject.id);
      button.textContent = mark === null ? "—" : String(mark);
      if (mark === null) button.classList.add("empty");
      if (mark !== null && mark <= 2) button.classList.add("failing");
      td.append(button); row.append(td);
    }
    body.append(row);
  }
}

/** Подсвечивает ячейку оценки: 2 и отсутствие оценки требуют внимания. */
function toggleClass(button, mark) {
  button.classList.toggle("empty", mark === null);
  button.classList.toggle("failing", mark !== null && mark <= 2);
  button.textContent = mark === null ? "—" : String(mark);
}

/** Загружает журнал выбранной группы. */
async function load(successText = "", groupId = null) {
  busy(true); message("Загрузка...");
  try {
    const suffix = groupId ? "?group_id=" + groupId : "";
    journal = await requestJSON(API + suffix);
    loaded = true;
    fillGroups(groupSelect, groups, false);
    groupSelect.value = String(journal.group.id);
    render();
    message(successText);
  } catch (error) {
    message((successText ? successText + " Обновление не удалось. " : "") + error.message, true);
    if (!loaded) { head.replaceChildren(); body.replaceChildren(); }
  } finally { busy(false); }
}

document.querySelector("#group-select").addEventListener("change", function() { load("", Number(groupSelect.value)); });
body.addEventListener("click", async function(event) {
  const button = event.target.closest("button[data-action='mark']"); if (!button) return;
  const studentId = Number(button.dataset.student);
  const subjectId = Number(button.dataset.subject);
  const current = findMark(studentId, subjectId);
  const next = current === null ? 5 : (current === 2 ? null : current - 1);
  busy(true);
  try {
    if (next === null) {
      await deleteGrade(studentId, subjectId);
      journal.grades = journal.grades.filter(function(row) {
        return !(row.student_id === studentId && row.subject_id === subjectId);
      });
      toggleClass(button, null); message("Оценка удалена.");
    } else {
      const item = (await saveGrade(studentId, subjectId, next)).item;
      const existing = journal.grades.find(function(row) {
        return row.student_id === studentId && row.subject_id === subjectId;
      });
      if (existing) existing.mark = item.mark; else journal.grades.push(item);
      toggleClass(button, item.mark); message("Оценка сохранена.");
    }
  } catch (error) { message(error.message, true); }
  finally { busy(false); }
});

requestJSON("/api/groups").then(function(data) {
  groups = data.items;
  return load();
}).catch(function(error) { message(error.message, true); });
