"""SQL раздела journal. Соединение передаёт сервис, commit здесь отсутствует."""

def get_group(con, record_id):
    """Находит группу журнала.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Идентификатор группы.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM groups WHERE id = ?
        ''',
        (record_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_students(con, group_id):
    """Возвращает студентов группы по алфавиту.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Идентификатор группы.

    Returns:
        list[dict]: Строки результата.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM students WHERE group_id = ? ORDER BY name, id
        ''',
        (group_id,),
    )
    return [dict(row) for row in cursor.fetchall()]


def get_subjects(con):
    """Возвращает все предметы журнала.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.

    Returns:
        list[dict]: Строки результата.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM subjects ORDER BY name, id
        ''',
        (),
    )
    return [dict(row) for row in cursor.fetchall()]


def get_grades(con, group_id):
    """Возвращает оценки студентов выбранной группы.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Идентификатор группы.

    Returns:
        list[dict]: Строки результата.
    """
    cursor = con.execute(
        '''
        SELECT gr.student_id, gr.subject_id, gr.mark
        FROM grades AS gr
        JOIN students AS s ON s.id = gr.student_id
        WHERE s.group_id = ?
        ORDER BY gr.student_id, gr.subject_id
        ''',
        (group_id,),
    )
    return [dict(row) for row in cursor.fetchall()]


def get_student(con, record_id):
    """Проверяет существование студента.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Идентификатор студента.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id FROM students WHERE id = ?
        ''',
        (record_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_subject(con, record_id):
    """Проверяет существование предмета.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Идентификатор предмета.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id FROM subjects WHERE id = ?
        ''',
        (record_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_grade(con, student_id, subject_id):
    """Находит оценку по паре студент и предмет.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Идентификатор студента.
        subject_id: Идентификатор предмета.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT student_id, subject_id, mark FROM grades WHERE student_id = ? AND subject_id = ?
        ''',
        (student_id, subject_id),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def insert_grade(con, student_id, subject_id, mark):
    """Вставляет оценку без фиксации транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id (int): Проверенный студент.
        subject_id (int): Проверенный предмет.
        mark (int): Допустимая оценка.

    Returns:
        int: Идентификатор новой записи.
    """
    cursor = con.execute(
        '''
        INSERT INTO grades (student_id, subject_id, mark) VALUES (?, ?, ?)
        ''',
        (student_id, subject_id, mark),
    )
    return cursor.lastrowid


def update_grade(con, mark, student_id, subject_id):
    """Изменяет оценку пары студент и предмет.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        mark (int): Допустимая оценка.
        student_id (int): Идентификатор студента.
        subject_id (int): Идентификатор предмета.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        UPDATE grades SET mark = ? WHERE student_id = ? AND subject_id = ?
        ''',
        (mark, student_id, subject_id),
    )


def delete_grade(con, student_id, subject_id):
    """Удаляет оценку пары студент и предмет.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id (int): Идентификатор студента.
        subject_id (int): Идентификатор предмета.

    Returns:
        int: Количество удалённых строк.
    """
    cursor = con.execute(
        '''
        DELETE FROM grades WHERE student_id = ? AND subject_id = ?
        ''',
        (student_id, subject_id),
    )
    return cursor.rowcount
