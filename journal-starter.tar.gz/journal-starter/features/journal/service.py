"""Бизнес-правила и транзакции раздела journal."""

import sqlite3
from db import connect_db
from . import repo

MARKS = (2, 3, 4, 5)


def journal(group_id=None):
    """Собирает данные журнала выбранной группы.

    Args:
        group_id (int | None): Группа из строки запроса.

    Returns:
        dict: Группа, студенты, предметы и оценки.

    Raises:
        ValueError: Группа не выбрана.
        LookupError: Группа не найдена.
    """
    con = connect_db()
    try:
        if group_id is None:
            row = con.execute("SELECT id FROM groups ORDER BY name, id LIMIT 1").fetchone()
            if row is None:
                raise ValueError("Сначала добавьте учебную группу.")
            group_id = row[0]
        group = repo.get_group(con, group_id)
        if group is None:
            raise LookupError("Группа не найдена.")
        return {
            "group": group,
            "students": repo.get_students(con, group_id),
            "subjects": repo.get_subjects(con),
            "grades": repo.get_grades(con, group_id),
        }
    finally:
        con.close()


def clean_mark(mark):
    """Проверяет оценку по списку допустимых значений.

    Args:
        mark: Значение из JSON-запроса.

    Returns:
        int: Допустимая оценка.

    Raises:
        ValueError: Оценка не входит в список.
    """
    if isinstance(mark, bool) or not isinstance(mark, int) or mark not in MARKS:
        raise ValueError("Оценка должна быть 2, 3, 4 или 5.")
    return mark


def save_grade(student_id, subject_id, mark):
    """Вставляет или изменяет оценку одной транзакцией.

    Args:
        student_id: Студент из JSON-запроса.
        subject_id: Предмет из JSON-запроса.
        mark: Оценка из JSON-запроса.

    Returns:
        dict: Сохранённая оценка.

    Raises:
        ValueError: Поля некорректны или родители отсутствуют.
        LookupError: Студент или предмет не найдены.
    """
    mark = clean_mark(mark)
    for value, label in ((student_id, "Студент"), (subject_id, "Предмет")):
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("Некорректный идентификатор: " + label.lower() + ".")
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, student_id) is None:
                raise LookupError("Студент не найден.")
            if repo.get_subject(con, subject_id) is None:
                raise LookupError("Предмет не найден.")
            if repo.get_grade(con, student_id, subject_id) is None:
                repo.insert_grade(con, student_id, subject_id, mark)
            else:
                repo.update_grade(con, mark, student_id, subject_id)
            result = repo.get_grade(con, student_id, subject_id)
        return result
    except sqlite3.IntegrityError as error:
        raise ValueError("Не удалось сохранить оценку.") from error
    finally:
        con.close()


def delete_grade(student_id, subject_id):
    """Удаляет оценку, если родители существуют.

    Args:
        student_id (int): Идентификатор студента.
        subject_id (int): Идентификатор предмета.

    Returns:
        None: Транзакция завершена, повторное удаление допустимо.

    Raises:
        LookupError: Студент или предмет не найдены.
    """
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, student_id) is None:
                raise LookupError("Студент не найден.")
            if repo.get_subject(con, subject_id) is None:
                raise LookupError("Предмет не найден.")
            repo.delete_grade(con, student_id, subject_id)
    finally:
        con.close()
