"""Бизнес-правила и транзакции раздела students."""

import sqlite3
from db import connect_db
from . import repo


def clean_values(name, group_id, email):
    """Проверяет формат полей студента и нормализует значения.

    Args:
        name: Имя из JSON-запроса.
        group_id: Группа из JSON-запроса.
        email: Почта из JSON-запроса.

    Returns:
        tuple: Проверенные имя, идентификатор группы и почта или None.

    Raises:
        ValueError: Поле не соответствует бизнес-правилу.
    """
    if not isinstance(name, str):
        raise ValueError("Введите имя студента.")
    name = name.strip()
    if not 1 <= len(name) <= 50:
        raise ValueError("Имя должно занимать от 1 до 50 символов.")
    if isinstance(group_id, bool) or not isinstance(group_id, int):
        raise ValueError("Выберите группу.")
    if email is None:
        email = ""
    if not isinstance(email, str):
        raise ValueError("Проверьте адрес почты.")
    email = email.strip()
    if email and ("@" not in email or email.startswith("@") or email.endswith("@")):
        raise ValueError("Проверьте адрес почты.")
    return name, group_id, email or None


def list_students(group_id=None, query=""):
    """Возвращает студентов для таблицы.

    Args:
        group_id (int | None): Фильтр по группе.
        query (str): Поисковая подстрока.

    Returns:
        list[dict]: Данные для JSON-ответа.
    """
    con = connect_db()
    try:
        return repo.list_students(con, group_id, query.strip() if query else "")
    finally:
        con.close()


def save_student(name, group_id, email, record_id=None):
    """Проверяет поля и сохраняет студента одной транзакцией.

    Args:
        name (str): Имя из JSON-запроса.
        group_id (int): Группа из JSON-запроса.
        email (str | None): Почта из JSON-запроса.
        record_id (int | None): ID записи при редактировании.

    Returns:
        dict: Сохранённая запись с неизменным ID.

    Raises:
        ValueError: Поля некорректны или группа отсутствует.
        LookupError: Редактируемая запись отсутствует.
    """
    name, group_id, email = clean_values(name, group_id, email)
    con = connect_db()
    try:
        with con:
            if record_id is not None and repo.get_student(con, record_id) is None:
                raise LookupError("Студент не найден.")
            if con.execute("SELECT 1 FROM groups WHERE id = ?", (group_id,)).fetchone() is None:
                raise ValueError("Выбранная группа не существует.")
            if record_id is None:
                record_id = repo.insert_student(con, name, group_id, email)
            else:
                repo.update_student(con, name, group_id, email, record_id)
            result = repo.get_student(con, record_id)
        return result
    except sqlite3.IntegrityError as error:
        raise ValueError("Не удалось сохранить студента. Проверьте поля.") from error
    finally:
        con.close()


def delete_student(record_id, simulate_error=False):
    """Удаляет студента и все его оценки одной транзакцией.

    Args:
        record_id (int): Идентификатор удаляемой записи.
        simulate_error (bool): Учебный сбой для проверки отката. Только Python.

    Returns:
        None: Транзакция завершена.

    Raises:
        LookupError: Студент отсутствует.
        RuntimeError: Учебный сбой проверки отката.
    """
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, record_id) is None:
                raise LookupError("Студент не найден.")
            repo.delete_grades(con, record_id)
            if simulate_error:
                raise RuntimeError("Учебный сбой после удаления оценок")
            repo.delete_student(con, record_id)
    finally:
        con.close()
