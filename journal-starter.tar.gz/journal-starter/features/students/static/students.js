import {requestJSON} from "/static/js/api.js";
import {cell, message, busy, actions, emptyRow, fillGroups} from "/static/js/ui.js";
const API = "/api/students";
const body = document.querySelector("#table-body");
const editor = document.querySelector("#editor");
const form = document.querySelector("#edit-form");
const idInput = document.querySelector("#record-id");
const nameInput = document.querySelector("#record-name");
const groupSelect = document.querySelector("#record-group");
const emailInput = document.querySelector("#record-email");
const confirmation = document.querySelector("#confirmation");
const filterGroup = document.querySelector("#filter-group");
const searchInput = document.querySelector("#search");
let items = [], groups = [], pendingId = null, loaded = false;
nameInput.maxLength = 50;

/** Отправляет добавление или изменение записи. */
async function saveRecord(recordId, payload) {
  const url = recordId ? API + "/" + recordId : API;
  return requestJSON(url, "POST", payload);
}

/** Отправляет удаление записи. */
async function deleteRecord(recordId) {
  return requestJSON(API + "/" + recordId, "DELETE");
}

/** Строит таблицу по массиву из API. */
function render() {
  body.replaceChildren();
  if (!items.length) { emptyRow(body, 4); return; }
  for (const item of items) {
    const row = document.createElement("tr");
    row.append(cell(item.name));
    row.append(cell(item.group_name));
    row.append(cell(item.email));
    const td = document.createElement("td"); td.append(actions(item.id)); row.append(td);
    body.append(row);
  }
}

/** Собирает адрес списка с учётом фильтра и поиска. */
function buildUrl() {
  const params = new URLSearchParams();
  if (filterGroup.value) params.set("group_id", filterGroup.value);
  const query = searchInput.value.trim();
  if (query) params.set("q", query);
  const suffix = params.toString();
  return suffix ? API + "?" + suffix : API;
}

/** Обновляет данные, сохраняя старую таблицу при неудачном запросе. */
async function load(successText = "") {
  busy(true); message("Загрузка...");
  try { items = (await requestJSON(buildUrl())).items; loaded = true; render(); message(successText); }
  catch (error) {
    message((successText ? successText + " Обновление списка не удалось. " : "") + error.message, true);
    if (!loaded) emptyRow(body, 4, "Данные не загружены");
  } finally { busy(false); }
}

/** Загружает справочник групп для фильтра и формы. */
async function loadGroups() {
  groups = (await requestJSON("/api/groups")).items;
  fillGroups(filterGroup, groups, true);
  fillGroups(groupSelect, groups);
}

/** Открывает одну форму для создания и изменения. */
function openEditor(item = null) {
  form.reset(); idInput.value = item ? String(item.id) : "";
  nameInput.value = item ? item.name : "";
  fillGroups(groupSelect, groups);
  groupSelect.value = item ? String(item.group_id) : (groups[0] ? String(groups[0].id) : "");
  emailInput.value = item && item.email ? item.email : "";
  document.querySelector("#editor-title").textContent = item ? "Изменение записи" : "Добавление записи";
  editor.hidden = false; confirmation.hidden = true; message(); nameInput.focus();
}

document.querySelector("#add-record").addEventListener("click", function() { openEditor(); });
document.querySelector("#cancel-edit").addEventListener("click", function() { editor.hidden = true; message(); });
form.addEventListener("submit", async function(event) {
  event.preventDefault();
  const name = nameInput.value.trim();
  if (!name) { message("Введите имя студента.", true); nameInput.focus(); return; }
  if (!groupSelect.value) { message("Выберите группу.", true); groupSelect.focus(); return; }
  busy(true);
  try {
    await saveRecord(idInput.value ? Number(idInput.value) : null, {
      name: name,
      group_id: Number(groupSelect.value),
      email: emailInput.value.trim(),
    });
    editor.hidden = true; form.reset(); await load("Изменения сохранены.");
  } catch (error) { message(error.message, true); }
  finally { busy(false); }
});
body.addEventListener("click", function(event) {
  const button = event.target.closest("button[data-action]"); if (!button) return;
  const item = items.find(function(record) { return record.id === Number(button.dataset.id); }); if (!item) return;
  if (button.dataset.action === "edit") { openEditor(item); return; }
  pendingId = item.id; editor.hidden = true; confirmation.hidden = false;
  document.querySelector("#confirmation-text").textContent = "Удалить «" + item.name + "» вместе с оценками?"; message();
});
document.querySelector("#cancel-delete").addEventListener("click", function() { pendingId = null; confirmation.hidden = true; });
document.querySelector("#confirm-delete").addEventListener("click", async function() {
  if (pendingId === null) return; busy(true);
  try { await deleteRecord(pendingId); confirmation.hidden = true; pendingId = null; await load("Студент удалён."); }
  catch (error) { message(error.message, true); } finally { busy(false); }
});
filterGroup.addEventListener("change", function() { load(); });
searchInput.addEventListener("input", function() { load(); });
loadGroups().then(function() { return load(); }).catch(function(error) { message(error.message, true); });
