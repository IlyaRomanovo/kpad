"""SQL раздела students. Соединение передаёт сервис, commit здесь отсутствует."""

def list_students(con, group_id=None, query=""):
    """Возвращает студентов с названием группы.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id (int | None): Фильтр по группе.
        query (str): Подстрока для поиска по имени и email.

    Returns:
        list[dict]: Строки результата.
    """
    sql = '''
        SELECT s.id, s.name, s.group_id, g.name AS group_name, s.email
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        WHERE 1 = 1
    '''
    params = []
    if group_id is not None:
        sql += " AND s.group_id = ?"
        params.append(group_id)
    if query:
        sql += " AND (s.name LIKE ? OR IFNULL(s.email, '') LIKE ?)"
        pattern = "%" + query + "%"
        params.extend((pattern, pattern))
    sql += " ORDER BY g.name, s.name, s.id"
    cursor = con.execute(sql, tuple(params))
    return [dict(row) for row in cursor.fetchall()]


def get_student(con, record_id):
    """Находит студента по идентификатору.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT s.id, s.name, s.group_id, g.name AS group_name, s.email
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        WHERE s.id = ?
        ''',
        (record_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def insert_student(con, name, group_id, email):
    """Добавляет студента без фиксации транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        name (str): Проверенное имя.
        group_id (int): Существующая группа.
        email (str | None): Почта либо None.

    Returns:
        int: Идентификатор новой записи.
    """
    cursor = con.execute(
        '''
        INSERT INTO students (name, group_id, email) VALUES (?, ?, ?)
        ''',
        (name, group_id, email),
    )
    return cursor.lastrowid


def update_student(con, name, group_id, email, record_id):
    """Изменяет студента, сохраняя идентификатор и оценки.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        name (str): Проверенное имя.
        group_id (int): Существующая группа.
        email (str | None): Почта либо None.
        record_id (int): Идентификатор изменяемой записи.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        UPDATE students SET name = ?, group_id = ?, email = ? WHERE id = ?
        ''',
        (name, group_id, email, record_id),
    )


def delete_grades(con, record_id):
    """Удаляет все оценки студента перед удалением самого студента.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Идентификатор студента.

    Returns:
        int: Количество удалённых оценок.
    """
    cursor = con.execute(
        '''
        DELETE FROM grades WHERE student_id = ?
        ''',
        (record_id,),
    )
    return cursor.rowcount


def delete_student(con, record_id):
    """Удаляет студента без фиксации транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Идентификатор удаляемой записи.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        DELETE FROM students WHERE id = ?
        ''',
        (record_id,),
    )
