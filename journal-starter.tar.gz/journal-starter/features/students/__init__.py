"""Функциональный срез Студенты."""

from flask import Blueprint

bp = Blueprint(
    "students",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/features/students/static",
)

from . import api, pages  # noqa: E402,F401
