"""Функциональный срез Отчёты."""

from flask import Blueprint

bp = Blueprint(
    "reports",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/features/reports/static",
)

from . import api, pages  # noqa: E402,F401
