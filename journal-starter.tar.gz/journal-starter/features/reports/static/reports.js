import {requestJSON} from "/static/js/api.js";
import {cell, message, busy, emptyRow} from "/static/js/ui.js";
const API = "/api/reports";
const kindSelect = document.querySelector("#report-kind");
const head = document.querySelector("#table-head");
const body = document.querySelector("#table-body");
let loaded = false;

/** Описание колонок для каждого вида отчёта. */
const COLUMNS = {
  groups: [
    ["name", "Группа", ""],
    ["student_count", "Студентов", "number"],
    ["grade_count", "Оценок", "number"],
    ["average_mark", "Средний балл", "number"],
  ],
  no_grades: [
    ["name", "Студент", ""],
    ["group_name", "Группа", ""],
  ],
  failing: [
    ["name", "Студент", ""],
    ["group_name", "Группа", ""],
  ],
};

/** Строит шапку таблицы под выбранный отчёт. */
function renderHead(columns) {
  head.replaceChildren();
  const row = document.createElement("tr");
  for (const column of columns) {
    const th = document.createElement("th"); th.textContent = column[1]; th.className = column[2];
    row.append(th);
  }
  head.append(row);
}

/** Строит таблицу по массиву из API. */
function render(kind, items) {
  const columns = COLUMNS[kind];
  renderHead(columns);
  body.replaceChildren();
  if (!items.length) { emptyRow(body, columns.length, "Нет данных для отчёта"); return; }
  for (const item of items) {
    const row = document.createElement("tr");
    for (const column of columns) row.append(cell(item[column[0]], column[2]));
    body.append(row);
  }
}

/** Загружает отчёт выбранного вида. */
async function load() {
  const kind = kindSelect.value;
  busy(true); message("Загрузка...");
  try {
    const payload = await requestJSON(API + "?kind=" + encodeURIComponent(kind));
    loaded = true; render(payload.kind, payload.items); message();
  } catch (error) {
    message(error.message, true);
    if (!loaded) { head.replaceChildren(); emptyRow(body, 2, "Данные не загружены"); }
  } finally { busy(false); }
}

kindSelect.addEventListener("change", load);
load();
