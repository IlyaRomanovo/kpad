"""SQL отчётов. Соединение передаёт сервис, commit здесь отсутствует."""

def group_report(con):
    """Считает студентов, оценки и средний балл по каждой группе.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.

    Returns:
        list[dict]: Строки отчёта.
    """
    cursor = con.execute(
        '''
        SELECT g.id, g.name,
               COUNT(DISTINCT s.id) AS student_count,
               COUNT(gr.id) AS grade_count,
               ROUND(AVG(gr.mark), 2) AS average_mark
        FROM groups AS g
        LEFT JOIN students AS s ON s.group_id = g.id
        LEFT JOIN grades AS gr ON gr.student_id = s.id
        GROUP BY g.id, g.name
        ORDER BY g.name, g.id
        ''',
        (),
    )
    return [dict(row) for row in cursor.fetchall()]


def no_grades_report(con):
    """Возвращает студентов без единой оценки.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.

    Returns:
        list[dict]: Строки отчёта.
    """
    cursor = con.execute(
        '''
        SELECT s.id, s.name, g.name AS group_name
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        LEFT JOIN grades AS gr ON gr.student_id = s.id
        WHERE gr.id IS NULL
        ORDER BY g.name, s.name, s.id
        ''',
        (),
    )
    return [dict(row) for row in cursor.fetchall()]


def failing_report(con):
    """Возвращает студентов с оценкой 2 хотя бы по одному предмету.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.

    Returns:
        list[dict]: Строки отчёта.
    """
    cursor = con.execute(
        '''
        SELECT s.id, s.name, g.name AS group_name
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        JOIN grades AS gr ON gr.student_id = s.id
        WHERE gr.mark = 2
        GROUP BY s.id, s.name, g.name
        HAVING COUNT(DISTINCT gr.subject_id) >= 1
        ORDER BY g.name, s.name, s.id
        ''',
        (),
    )
    return [dict(row) for row in cursor.fetchall()]
