"""Бизнес-правила раздела reports."""

import sqlite3
from db import connect_db
from . import repo

KINDS = ("groups", "no_grades", "failing")


def report(kind="groups"):
    """Проверяет вид отчёта и возвращает строки.

    Args:
        kind (str): Вид отчёта из строки запроса.

    Returns:
        dict: Поле kind и массив items.

    Raises:
        ValueError: Вид отчёта не поддерживается.
    """
    if kind not in KINDS:
        raise ValueError("Неизвестный вид отчёта.")
    con = connect_db()
    try:
        if kind == "groups":
            items = repo.group_report(con)
        elif kind == "no_grades":
            items = repo.no_grades_report(con)
        else:
            items = repo.failing_report(con)
        return {"kind": kind, "items": items}
    finally:
        con.close()
