"""HTTP и JSON раздела reports. SQL находится в repo."""

from flask import request
from . import bp, service


@bp.get("/api/reports")
def get_items():
    """Возвращает выбранный отчёт.

    Returns:
        dict: Поле kind и массив items.
    """
    kind = request.args.get("kind", "groups", type=str)
    return service.report(kind)
