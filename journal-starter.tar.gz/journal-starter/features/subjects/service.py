"""Бизнес-правила и транзакции раздела subjects."""

import sqlite3
from db import connect_db
from . import repo


def list_subjects():
    """Возвращает записи справочника.

    Returns:
        list[dict]: Данные для JSON-ответа.
    """
    con = connect_db()
    try:
        return repo.list_subjects(con)
    finally:
        con.close()


def save_subject(name, record_id=None):
    """Проверяет название и сохраняет запись одной транзакцией.

    Args:
        name (str): Название из JSON-запроса.
        record_id (int | None): ID записи при редактировании.

    Returns:
        dict: Сохранённая запись с неизменным ID.

    Raises:
        ValueError: Название некорректно или занято.
        LookupError: Редактируемая запись отсутствует.
    """
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Введите название предмета.")
    name = name.strip()
    con = connect_db()
    try:
        with con:
            if record_id is not None and repo.get_subject(con, record_id) is None:
                raise LookupError("Предмет не найден.")
            if record_id is None:
                record_id = repo.insert_subject(con, name)
            else:
                repo.update_subject(con, name, record_id)
            result = repo.get_subject(con, record_id)
        return result
    except sqlite3.IntegrityError as error:
        raise ValueError("Такое название уже существует.") from error
    finally:
        con.close()


def delete_subject(record_id):
    """Удаляет предмет при отсутствии оценок.

    Args:
        record_id (int): Идентификатор удаляемой записи.

    Returns:
        None: Транзакция завершена.

    Raises:
        LookupError: Запись отсутствует.
        ValueError: Внешний ключ запрещает удаление.
    """
    con = connect_db()
    try:
        with con:
            if repo.get_subject(con, record_id) is None:
                raise LookupError("Предмет не найден.")
            repo.delete_subject(con, record_id)
    except sqlite3.IntegrityError as error:
        raise ValueError("По предмету уже выставлены оценки. Удаление запрещено.") from error
    finally:
        con.close()
