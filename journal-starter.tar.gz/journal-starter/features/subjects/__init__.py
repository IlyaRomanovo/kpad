"""Функциональный срез Предметы."""

from flask import Blueprint

bp = Blueprint(
    "subjects",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/features/subjects/static",
)

from . import api, pages  # noqa: E402,F401
