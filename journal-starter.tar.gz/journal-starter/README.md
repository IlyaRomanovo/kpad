# Электронный журнал

Итоговый проект студента. Три недели, шесть лабораторных пар по 90 минут, всего 12 академических часов.
Проект использует Flask, Jinja2, обычный JavaScript и модуль Python sqlite3.
Python 3.11 или новее. В браузере должен быть включён JavaScript.

## Запуск в Debian Linux

Один раз подготовьте системные пакеты:

~~~bash
sudo apt update
sudo apt install python3 python3-venv python3-pip sqlite3 unzip
~~~

После распаковки архива:

~~~bash
cd journal-starter
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python prepare_db.py
python check_db.py --baseline
python app.py
~~~

Откройте http://127.0.0.1:5000/. Остановка сервера: Ctrl+C.
Повторный запуск после закрытия терминала:

~~~bash
cd journal-starter
source .venv/bin/activate
python app.py
~~~

## Исходная база и восстановление

База instance/journal.db создаётся явно. Исходные данные: 3 группы БЭИ2301,
БЭИ2302, БЭИ2303, по 20 студентов, 3 предмета и 162 оценки. Без оценок остаются
студенты с ID 10, 20, 30, 40, 50, 60. Группы и предметы можно добавлять.
Оценка одна на пару студент и предмет. Пустая ячейка означает отсутствие строки,
а не оценку 0. Email необязателен, одинаковые имена и email допустимы.

Для восстановления остановите сервер и выполните:

~~~bash
python prepare_db.py
python check_db.py --baseline
python app.py
~~~

Восстановление заменяет текущие учебные данные исходными. Схема и заполнение
выполняются одной транзакцией. При SQL-ошибке скрипт откатывает изменения.
Обработчик with con фиксирует или откатывает транзакцию, а соединение
дополнительно закрывается в finally. Репозитории commit не вызывают.

## Консоль SQLite

Во втором терминале из корня проекта:

~~~bash
sqlite3 instance/journal.db
~~~

Внутри консоли:

~~~sql
PRAGMA foreign_keys = ON;
PRAGMA foreign_keys;
.headers on
.mode column
SELECT g.name, COUNT(s.id) AS students
FROM groups AS g LEFT JOIN students AS s ON s.group_id = g.id
GROUP BY g.id, g.name;
PRAGMA foreign_key_check;
.quit
~~~

foreign_keys должен вернуть 1; foreign_key_check не должен вернуть строк.
Настройка включается для каждого соединения отдельно до BEGIN.

## Вертикальные срезы

Каждый каталог features/groups, subjects, students, journal, reports
объединяет один функциональный раздел. Blueprint создаётся в __init__.py
и регистрируется в app.py. pages.py возвращает только HTML. api.py читает
HTTP и JSON. service.py проверяет бизнес-правила, открывает соединение и
управляет транзакцией. repo.py выполняет SQL через переданное соединение.
HTML и JS находятся внутри соответствующего среза.

Общие части: db.py, templates/base.html, templates/partials/header.html,
templates/partials/footer.html, static/css/styles.css, static/js/api.js,
static/js/ui.js. Переходы между разделами обычными ссылками. Действия
пользователя обрабатывает JS, который вызывает JSON API.

## План шести пар

1. Вертикальный срез и Blueprint, запуск, БД и готовый пример групп.
2. Предметы: POST, DELETE, сервис, SQL и два вызова из JS.
3. Студенты: сохранение, перевод и атомарное удаление с оценками.
4. Журнал: SELECT, INSERT либо UPDATE оценки и удаление оценки.
5. Три отчёта: GROUP BY, HAVING, LEFT JOIN и COUNT DISTINCT.
6. Полный откат, восстановление, README и итоговая демонстрация.

## Проверка отката

После реализации удаления студента:

~~~bash
python check_rollback.py
~~~

Скрипт создаёт временную копию БД через sqlite3.backup, вызывает тот же
service.delete_student, что и API, и вызывает учебный сбой после удаления
оценок. Параметр simulate_error доступен только в Python и не принимается
HTTP API. Скрипт сравнивает все строки четырёх таблиц до и после отката,
затем проверяет обычное удаление на копии. Рабочая база остаётся прежней.

## Контракты API

GET /api/groups и GET /api/subjects возвращают {"items": [...]}.
POST /api/groups или /api/subjects создаёт запись с JSON {"name": "..."}.
POST по адресу /api/groups/ID или /api/subjects/ID переименовывает запись.
Ответ: {"item": {"id": ..., "name": ...}}, статус 201 при создании и 200 при изменении.
DELETE /api/groups/ID и /api/subjects/ID возвращает пустой ответ 204.

GET /api/students возвращает items; можно передать group_id и q.
POST /api/students и POST /api/students/ID принимают name, group_id, email.
DELETE /api/students/ID удаляет студента и оценки одной транзакцией.

GET /api/journal?group_id=1 возвращает group, students, subjects, grades.
POST /api/journal/grades принимает student_id, subject_id, mark и возвращает item, статус 200.
DELETE /api/journal/grades/STUDENT_ID/SUBJECT_ID возвращает 204.
Повторное удаление пустой оценки также возвращает 204, если родители существуют.

GET /api/reports?kind=groups, no_grades или failing возвращает kind и items.
В отчёте групп поля id, name, student_count, grade_count, average_mark.
В остальных отчётах id, name, group_name. Средний балл пустой группы равен null.
Ошибки полей и зависимостей: 400 и {"error": "..."}; отсутствующая запись: 404.
Техническая ошибка БД: 500. Тело ответа 204 разбирать как JSON не нужно.

## Сдача

Сохраните проект в Git и фиксируйте результат после каждого этапа.
К сдаче подготовьте исходники, схему и данные, рабочий скрипт восстановления,
команды запуска и результаты проверок. Дополните этот README описанием
самостоятельно реализованных функций. Покажите перевод без потери оценок,
запрет удаления связанных справочников, отчёты и полный откат.

## Справочные материалы

Flask Blueprint: https://flask.palletsprojects.com/en/stable/blueprints/
Python sqlite3: https://docs.python.org/3.11/library/sqlite3.html
Внешние ключи SQLite: https://www.sqlite.org/foreignkeys.html
Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

## Выполненные задания LAB2–LAB5

Все пять разделов реализованы. Заглушек `NotImplementedError` в рабочих
функциях не осталось; обработчик 501 в app.py оставлен как часть каркаса.

### LAB2 — Предметы

- `subjects/api.py: save_item` различает создание и переименование по `record_id`, отдаёт 201 либо 200.
- `subjects/api.py: delete_item` возвращает 204 после успешного удаления.
- `subjects/service.py: save_subject` отрезает края, требует непустое название, ловит `sqlite3.IntegrityError` от ограничения `UNIQUE` и переводит его в 400.
- `subjects/service.py: delete_subject` проверяет существование записи (404), а запрет удаления предмета с оценками отдаёт внешний ключ `grades.subject_id` → 400.
- `subjects/repo.py`: `insert_subject`, `update_subject`, `delete_subject` выполняют параметризованный SQL без `commit`.

### LAB3 — Студенты

- `students/service.py: clean_values` — готовая проверка полей: длина имени 1–50 после `strip`, обязательный числовой `group_id`, email необязателен, пустая строка превращается в `NULL`.
- `students/service.py: save_student` проверяет существование группы (400) и редактируемой записи (404). Переименование сохраняет `id`, поэтому оценки остаются привязанными к студенту.
- `students/service.py: delete_student` удаляет оценки и студента в одной транзакции `with con`. Параметр `simulate_error` поднимает `RuntimeError` после удаления оценок, и `with con` откатывает всё — это и проверяет `check_rollback.py`.
- `students/repo.py`: `delete_grades` идёт первой, затем `delete_student`; порядок важен из-за внешнего ключа.

### LAB4 — Журнал

- `journal/service.py: journal` собирает группу, студентов, предметы и оценки; при отсутствии `group_id` берёт первую группу по алфавиту.
- `journal/service.py: save_grade` допускает только 2, 3, 4, 5 и делает INSERT либо UPDATE в зависимости от наличия строки пары студент-предмет.
- `journal/service.py: delete_grade` проверяет родителей (404) и допускает повторное удаление отсутствующей оценки с ответом 204.
- `journal.js` циклически меняет оценку по клику: 5 → 4 → 3 → 2 → пусто, затем снова 5.

### LAB5 — Отчёты

- `reports/repo.py: group_report` — `LEFT JOIN` двух уровней, `COUNT(DISTINCT s.id)`, `COUNT(gr.id)` и `ROUND(AVG(gr.mark), 2)`. У пустой группы `AVG` даёт `NULL`, что и требуется.
- `reports/repo.py: no_grades_report` — `LEFT JOIN grades` с условием `gr.id IS NULL`.
- `reports/repo.py: failing_report` — `JOIN grades`, фильтр `mark = 2`, `GROUP BY` с `HAVING COUNT(DISTINCT gr.subject_id) >= 1`.

### Результаты проверок

~~~text
python prepare_db.py
База восстановлена: instance/journal.db
groups: 3
students: 60
subjects: 3
grades: 162

python check_db.py --baseline
foreign_keys: 1
foreign_key_check: 0
groups: 3
students: 60
subjects: 3
grades: 162
students_without_grades: 6
PASS: база прошла проверку

python check_rollback.py
Учебный сбой: Учебный сбой после удаления оценок
PASS: студент и все оценки сохранены после отката
PASS: обычное удаление убрало студента и его оценки
PASS: рабочая база не изменена проверкой
~~~
