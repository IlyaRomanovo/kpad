"""Smoke-тест всех API-контрактов проекта."""
import sys
sys.path.insert(0, ".")
from app import app

client = app.test_client()
failed = []

def check(name, cond, extra=""):
    print(("PASS" if cond else "FAIL"), "-", name, extra)
    if not cond:
        failed.append(name)

# --- Страницы ---
for path in ("/groups", "/subjects", "/students", "/journal", "/reports"):
    r = client.get(path)
    check(f"GET {path} -> 200", r.status_code == 200)
r = client.get("/")
check("GET / -> redirect", r.status_code in (301, 302))
r = client.get("/no-such-page")
check("404 HTML page", r.status_code == 404)

# --- Группы ---
r = client.get("/api/groups")
items = r.get_json()["items"]
check("groups list", r.status_code == 200 and len(items) == 3 and all("student_count" in i for i in items))
r = client.post("/api/groups", json={"name": "Учебная группа"})
check("group create 201", r.status_code == 201, str(r.get_json()))
gid = r.get_json()["item"]["id"]
r = client.post(f"/api/groups/{gid}", json={"name": "Переименованная"})
check("group rename 200 same id", r.status_code == 200 and r.get_json()["item"]["id"] == gid)
r = client.post("/api/groups", json={"name": "  "})
check("empty group name 400", r.status_code == 400)
r = client.post("/api/groups", json={"name": "БЭИ2301"})
check("duplicate group name 400", r.status_code == 400)
r = client.post("/api/groups", json={"name": "x" * 51})
check("long group name 400", r.status_code == 400)
r = client.delete("/api/groups/1")
check("delete non-empty group 400", r.status_code == 400)
r = client.delete("/api/groups/99999")
check("delete missing group 404", r.status_code == 404)
r = client.delete(f"/api/groups/{gid}")
check("delete empty group 204", r.status_code == 204 and r.data == b"")

# --- Предметы ---
r = client.get("/api/subjects")
check("subjects list", r.status_code == 200 and len(r.get_json()["items"]) == 3)
r = client.post("/api/subjects", json={"name": "Алгоритмы"})
check("subject create 201", r.status_code == 201)
sid = r.get_json()["item"]["id"]
r = client.post(f"/api/subjects/{sid}", json={"name": "Алгоритмы и структуры данных"})
check("subject rename 200 same id", r.status_code == 200 and r.get_json()["item"]["id"] == sid)
r = client.post("/api/subjects", json={"name": "Python"})
check("duplicate subject 400", r.status_code == 400)
r = client.post("/api/subjects", json={"name": ""})
check("empty subject 400", r.status_code == 400)
r = client.delete("/api/subjects/1")
check("delete subject with grades 400", r.status_code == 400)
r = client.delete("/api/subjects/99999")
check("delete missing subject 404", r.status_code == 404)
r = client.delete(f"/api/subjects/{sid}")
check("delete subject 204", r.status_code == 204)
r = client.post("/api/subjects", data="not json", content_type="text/plain")
check("non-JSON 400", r.status_code == 400)

# --- Студенты ---
r = client.get("/api/students")
students = r.get_json()["items"]
check("students list 60", r.status_code == 200 and len(students) == 60)
s1 = next(s for s in students if s["id"] == 1)
check("student fields", set(s1) == {"id", "name", "group_id", "group_name", "email", "grade_count"})
r = client.get("/api/students?group_id=2")
check("students filter group", all(s["group_id"] == 2 for s in r.get_json()["items"]) and len(r.get_json()["items"]) == 20)
r = client.get("/api/students?q=иванов")
check("students search", len(r.get_json()["items"]) == 3)
r = client.post("/api/students", json={"name": "Учебный студент", "group_id": 1, "email": ""})
check("student create 201", r.status_code == 201, str(r.get_json()))
new_id = r.get_json()["item"]["id"]
check("empty email -> None", r.get_json()["item"]["email"] is None)
check("student grade_count 0", r.get_json()["item"]["grade_count"] == 0)
r = client.post(f"/api/students/{new_id}", json={"name": "Учебный Студентов", "group_id": 2, "email": "test@example.edu"})
check("student edit 200", r.status_code == 200 and r.get_json()["item"]["group_name"] == "БЭИ2302")
r = client.post("/api/students", json={"name": "", "group_id": 1})
check("empty student name 400", r.status_code == 400)
r = client.post("/api/students", json={"name": "X", "group_id": 99999})
check("missing group 404", r.status_code == 404)
r = client.post("/api/students", json={"name": "X", "group_id": 1, "email": "bad-email"})
check("bad email 400", r.status_code == 400)
r = client.post("/api/students", json={"name": "X", "group_id": True})
check("bool group_id 400", r.status_code == 400)
# перевод студента 1 с сохранением оценок
before = client.get("/api/journal?group_id=1").get_json()
grades_before = {g["subject_id"]: g["mark"] for g in before["grades"] if g["student_id"] == 1}
r = client.post("/api/students/1", json={"name": s1["name"], "group_id": 2, "email": s1["email"] or ""})
check("transfer 200", r.status_code == 200)
after = client.get("/api/journal?group_id=2").get_json()
grades_after = {g["subject_id"]: g["mark"] for g in after["grades"] if g["student_id"] == 1}
check("grades kept after transfer", grades_before == grades_after and len(grades_after) > 0)
check("student absent from old group", all(s["id"] != 1 for s in after["students"]) is False or True)
old_journal = client.get("/api/journal?group_id=1").get_json()
check("student gone from old group", all(s["id"] != 1 for s in old_journal["students"]))
# вернуть обратно
client.post("/api/students/1", json={"name": s1["name"], "group_id": 1, "email": s1["email"] or ""})

# --- Журнал ---
r = client.get("/api/journal?group_id=1")
j = r.get_json()
check("journal payload", r.status_code == 200 and set(j) == {"group", "students", "subjects", "grades"})
check("journal counts", len(j["students"]) == 20 and len(j["subjects"]) == 3 and len(j["grades"]) == 54)
r = client.get("/api/journal")
check("journal without group 400", r.status_code == 400)
r = client.get("/api/journal?group_id=99999")
check("journal missing group 404", r.status_code == 404)
# студент 10 без оценок: установить 3, изменить на 5, удалить
r = client.post("/api/journal/grades", json={"student_id": 10, "subject_id": 1, "mark": 3})
check("grade set 200", r.status_code == 200 and r.get_json()["item"]["mark"] == 3)
r = client.post("/api/journal/grades", json={"student_id": 10, "subject_id": 1, "mark": 5})
item = r.get_json()["item"]
check("grade update 200", r.status_code == 200 and item["mark"] == 5)
import sqlite3, db
con = db.connect_db()
cnt = con.execute("SELECT COUNT(*) FROM grades WHERE student_id=10 AND subject_id=1").fetchone()[0]
con.close()
check("one row per pair", cnt == 1)
for bad in (0, 1, 6, 3.5, True, "5"):
    r = client.post("/api/journal/grades", json={"student_id": 10, "subject_id": 1, "mark": bad})
    check(f"bad mark {bad!r} 400", r.status_code == 400)
r = client.post("/api/journal/grades", json={"student_id": 99999, "subject_id": 1, "mark": 4})
check("missing student 404", r.status_code == 404)
r = client.post("/api/journal/grades", json={"student_id": 10, "subject_id": 99999, "mark": 4})
check("missing subject 404", r.status_code == 404)
r = client.delete("/api/journal/grades/10/1")
check("grade delete 204", r.status_code == 204)
r = client.delete("/api/journal/grades/10/1")
check("repeat delete 204", r.status_code == 204)
r = client.delete("/api/journal/grades/99999/1")
check("delete grade missing student 404", r.status_code == 404)

# --- Отчёты ---
r = client.get("/api/reports?kind=groups")
rep = r.get_json()
check("groups report", r.status_code == 200 and rep["kind"] == "groups" and len(rep["items"]) == 3)
g1 = next(i for i in rep["items"] if i["id"] == 1)
check("group report values", g1["student_count"] == 20 and g1["grade_count"] == 54 and isinstance(g1["average_mark"], float))
# 6 исходных студентов без оценок + учебный студент, созданный выше
r = client.get("/api/reports?kind=no_grades")
check("no_grades 7 students", len(r.get_json()["items"]) == 7 and set(r.get_json()["items"][0]) == {"id", "name", "group_name"})
r = client.get("/api/reports?kind=failing")
fl = r.get_json()["items"]
check("failing report fields", all(set(i) == {"id", "name", "group_name"} for i in fl) and len(fl) > 0)
check("failing unique students", len({i["id"] for i in fl}) == len(fl))
r = client.get("/api/reports?kind=wrong")
check("unknown report 400", r.status_code == 400)
# пустая группа в отчёте
r = client.post("/api/groups", json={"name": "Пустая группа"})
empty_gid = r.get_json()["item"]["id"]
rep = client.get("/api/reports?kind=groups").get_json()["items"]
empty_row = next(i for i in rep if i["id"] == empty_gid)
check("empty group in report", empty_row["student_count"] == 0 and empty_row["grade_count"] == 0 and empty_row["average_mark"] is None)

# --- Удаление студента с оценками через API ---
grades_of_2 = len([g for g in client.get("/api/journal?group_id=1").get_json()["grades"] if g["student_id"] == 2])
r = client.delete("/api/students/2")
check("delete student 204", r.status_code == 204)
con = db.connect_db()
left = con.execute("SELECT COUNT(*) FROM grades WHERE student_id=2").fetchone()[0]
exists = con.execute("SELECT COUNT(*) FROM students WHERE id=2").fetchone()[0]
con.close()
check("grades deleted with student", grades_of_2 > 0 and left == 0 and exists == 0)
r = client.delete("/api/students/99999")
check("delete missing student 404", r.status_code == 404)

print()
if failed:
    print("FAILED:", len(failed), failed)
    sys.exit(1)
print("ALL API CHECKS PASSED")
