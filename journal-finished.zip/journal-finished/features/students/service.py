"""Бизнес-правила и транзакции раздела students."""

import re
from db import connect_db
from . import repo

EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def clean_values(name, group_id, email):
    """Проверяет формат полей студента и нормализует значения.

    Args:
        name: Имя из JSON-запроса.
        group_id: Идентификатор группы из JSON-запроса.
        email: Необязательный email из JSON-запроса.

    Returns:
        tuple: Очищенные name, group_id и email либо None.

    Raises:
        ValueError: Поле не прошло проверку формата.
    """
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Введите имя студента.")
    name = name.strip()
    if len(name) > 50:
        raise ValueError("Допускается не более 50 символов.")
    if isinstance(group_id, bool) or not isinstance(group_id, int) or group_id <= 0:
        raise ValueError("Выберите группу.")
    if email is None:
        email = None
    elif isinstance(email, str):
        email = email.strip()
        if not email:
            email = None
        elif len(email) > 100 or not EMAIL_PATTERN.match(email):
            raise ValueError("Некорректный email.")
    else:
        raise ValueError("Некорректный email.")
    return name, group_id, email


def list_students(group_id=None, q=None):
    """Возвращает записи студентов с необязательными фильтрами.

    Args:
        group_id (int | None): Фильтр по группе из параметров запроса.
        q (str | None): Фильтр по части имени.

    Returns:
        list[dict]: Данные для JSON-ответа.
    """
    con = connect_db()
    try:
        return repo.list_students(con, group_id, q)
    finally:
        con.close()


def save_student(name, group_id, email, record_id=None):
    """Проверяет поля и сохраняет студента одной транзакцией.

    Args:
        name (str): Имя из JSON-запроса.
        group_id (int): Группа из JSON-запроса.
        email (str | None): Необязательный email.
        record_id (int | None): ID записи при редактировании.

    Returns:
        dict: Сохранённая запись с неизменным ID и числом оценок.

    Raises:
        ValueError: Поля некорректны.
        LookupError: Группа либо редактируемый студент отсутствует.
    """
    name, group_id, email = clean_values(name, group_id, email)
    con = connect_db()
    try:
        with con:
            if repo.get_group(con, group_id) is None:
                raise LookupError("Группа не найдена.")
            if record_id is not None and repo.get_student(con, record_id) is None:
                raise LookupError("Студент не найден.")
            if record_id is None:
                record_id = repo.insert_student(con, name, group_id, email)
            else:
                repo.update_student(con, name, group_id, email, record_id)
            result = repo.get_student(con, record_id)
        return result
    finally:
        con.close()


def delete_student(student_id, simulate_error=False):
    """Удаляет оценки и студента в одной транзакции.

    Args:
        student_id (int): Идентификатор удаляемого студента.
        simulate_error (bool): Учебный сбой между двумя DELETE;
            HTTP API этот параметр не передаёт.

    Returns:
        None: Транзакция завершена.

    Raises:
        LookupError: Студент отсутствует.
        RuntimeError: Учебная ошибка для проверки полного отката.
    """
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, student_id) is None:
                raise LookupError("Студент не найден.")
            repo.delete_grades(con, student_id)
            if simulate_error:
                raise RuntimeError("Учебная ошибка после удаления оценок.")
            repo.delete_student(con, student_id)
    finally:
        con.close()
