"""SQL раздела students. Соединение передаёт сервис, commit здесь отсутствует."""

def list_students(con, group_id=None, q=None):
    """Возвращает студентов с названием группы и числом оценок.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id (int | None): Необязательный фильтр по группе.
        q (str | None): Необязательный фильтр по части имени.

    Returns:
        list[dict]: Строки результата.
    """
    sql = '''
        SELECT s.id, s.name, s.group_id, g.name AS group_name, s.email,
               COUNT(gr.id) AS grade_count
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        LEFT JOIN grades AS gr ON gr.student_id = s.id
    '''
    conditions = []
    params = []
    if group_id is not None:
        conditions.append("s.group_id = ?")
        params.append(group_id)
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += " GROUP BY s.id, s.name, s.group_id, g.name, s.email ORDER BY s.name, s.id"
    cursor = con.execute(sql, params)
    rows = [dict(row) for row in cursor.fetchall()]
    # SQLite сравнивает регистр только для латиницы, поэтому поиск
    # по имени выполняется в Python и работает с кириллицей.
    if q:
        needle = q.lower()
        rows = [row for row in rows if needle in row["name"].lower()]
    return rows


def get_student(con, record_id):
    """Находит студента с названием группы и числом оценок.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        record_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT s.id, s.name, s.group_id, g.name AS group_name, s.email,
               COUNT(gr.id) AS grade_count
        FROM students AS s
        JOIN groups AS g ON g.id = s.group_id
        LEFT JOIN grades AS gr ON gr.student_id = s.id
        WHERE s.id = ?
        GROUP BY s.id, s.name, s.group_id, g.name, s.email
        ''',
        (record_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_group(con, group_id):
    """Находит группу по идентификатору.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM groups WHERE id = ?
        ''',
        (group_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def insert_student(con, name, group_id, email):
    """Добавляет студента без фиксации транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        name: Значение параметра запроса.
        group_id: Значение параметра запроса.
        email: Значение параметра запроса либо None.

    Returns:
        int: Идентификатор новой записи.
    """
    cursor = con.execute(
        '''
        INSERT INTO students (name, group_id, email) VALUES (?, ?, ?)
        ''',
        (name, group_id, email),
    )
    return cursor.lastrowid


def update_student(con, name, group_id, email, record_id):
    """Изменяет поля студента; оценки остаются при стабильном ID.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        name: Значение параметра запроса.
        group_id: Значение параметра запроса.
        email: Значение параметра запроса либо None.
        record_id: Значение параметра запроса.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        UPDATE students SET name = ?, group_id = ?, email = ? WHERE id = ?
        ''',
        (name, group_id, email, record_id),
    )


def delete_grades(con, student_id):
    """Удаляет все оценки студента внутри общей транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        DELETE FROM grades WHERE student_id = ?
        ''',
        (student_id,),
    )


def delete_student(con, student_id):
    """Удаляет студента после удаления его оценок.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        DELETE FROM students WHERE id = ?
        ''',
        (student_id,),
    )
