import {requestJSON} from "/static/js/api.js";
import {cell, message, busy, actions, emptyRow, fillGroups} from "/static/js/ui.js";
const API = "/api/students";
const body = document.querySelector("#table-body");
const editor = document.querySelector("#editor");
const form = document.querySelector("#edit-form");
const idInput = document.querySelector("#record-id");
const nameInput = document.querySelector("#record-name");
const groupSelect = document.querySelector("#record-group");
const emailInput = document.querySelector("#record-email");
const confirmation = document.querySelector("#confirmation");
const searchInput = document.querySelector("#search");
const groupFilter = document.querySelector("#group-filter");
let items = [], pendingId = null, loaded = false;
nameInput.maxLength = 50;

/** Отправляет добавление или изменение студента. */
async function saveRecord(recordId, payload) {
  const url = recordId ? API + "/" + recordId : API;
  return requestJSON(url, "POST", payload);
}

/** Отправляет удаление студента вместе с оценками. */
async function deleteRecord(recordId) {
  return requestJSON(API + "/" + recordId, "DELETE");
}

/** Фильтрует уже загруженный массив поиском и выбором группы. */
function visibleItems() {
  const q = searchInput.value.trim().toLowerCase();
  const groupId = groupFilter.value;
  return items.filter(function(item) {
    if (groupId && String(item.group_id) !== groupId) return false;
    if (q && item.name.toLowerCase().indexOf(q) === -1) return false;
    return true;
  });
}

/** Строит таблицу по отфильтрованному массиву. */
function render() {
  body.replaceChildren();
  const rows = visibleItems();
  if (!rows.length) { emptyRow(body, 5, loaded ? "Записей нет" : "Данные не загружены"); return; }
  for (const item of rows) {
    const row = document.createElement("tr");
    row.append(cell(item.name));
    row.append(cell(item.group_name));
    row.append(cell(item.email));
    row.append(cell(item.grade_count, "number"));
    const td = document.createElement("td"); td.append(actions(item.id)); row.append(td);
    body.append(row);
  }
}

/** Обновляет данные, сохраняя старую таблицу при неудачном запросе. */
async function load(successText = "") {
  busy(true); message("Загрузка...");
  try { items = (await requestJSON(API)).items; loaded = true; render(); message(successText); }
  catch (error) {
    message((successText ? successText + " Обновление списка не удалось. " : "") + error.message, true);
    if (!loaded) emptyRow(body, 5, "Данные не загружены");
  } finally { busy(false); }
}

/** Загружает группы для фильтра и формы. */
async function loadGroups() {
  try {
    const groups = (await requestJSON("/api/groups")).items;
    fillGroups(groupFilter, groups, true);
    fillGroups(groupSelect, groups);
  } catch (error) { message(error.message, true); }
}

/** Открывает одну форму для создания и изменения. */
function openEditor(item = null) {
  form.reset(); idInput.value = item ? String(item.id) : "";
  nameInput.value = item ? item.name : "";
  if (item) groupSelect.value = String(item.group_id);
  emailInput.value = item && item.email ? item.email : "";
  document.querySelector("#editor-title").textContent = item ? "Изменение записи" : "Добавление записи";
  editor.hidden = false; confirmation.hidden = true; message(); nameInput.focus();
}

document.querySelector("#add-record").addEventListener("click", function() { openEditor(); });
document.querySelector("#cancel-edit").addEventListener("click", function() { editor.hidden = true; message(); });
searchInput.addEventListener("input", render);
groupFilter.addEventListener("change", render);
form.addEventListener("submit", async function(event) {
  event.preventDefault(); const name = nameInput.value.trim();
  if (!name) { message("Введите имя студента.", true); nameInput.focus(); return; }
  if (!groupSelect.value) { message("Выберите группу.", true); groupSelect.focus(); return; }
  busy(true);
  try {
    await saveRecord(idInput.value ? Number(idInput.value) : null, {
      name: name, group_id: Number(groupSelect.value), email: emailInput.value.trim()
    });
    editor.hidden = true; form.reset(); await load("Изменения сохранены.");
  } catch (error) { message(error.message, true); }
  finally { busy(false); }
});
body.addEventListener("click", function(event) {
  const button = event.target.closest("button[data-action]"); if (!button) return;
  const item = items.find(function(record) { return record.id === Number(button.dataset.id); }); if (!item) return;
  if (button.dataset.action === "edit") { openEditor(item); return; }
  pendingId = item.id; editor.hidden = true; confirmation.hidden = false;
  document.querySelector("#confirmation-text").textContent =
    "Удалить студента «" + item.name + "»? Вместе с ним будут удалены его оценки: " + item.grade_count + ".";
  message();
});
document.querySelector("#cancel-delete").addEventListener("click", function() { pendingId = null; confirmation.hidden = true; });
document.querySelector("#confirm-delete").addEventListener("click", async function() {
  if (pendingId === null) return; busy(true);
  try { await deleteRecord(pendingId); confirmation.hidden = true; pendingId = null; await load("Студент удалён."); }
  catch (error) { message(error.message, true); } finally { busy(false); }
});
loadGroups(); load();
