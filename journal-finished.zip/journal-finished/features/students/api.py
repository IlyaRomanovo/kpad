"""HTTP и JSON раздела students. SQL и бизнес-правила находятся ниже."""

from flask import request
from . import bp, service


@bp.get("/api/students")
def get_items():
    """Возвращает список студентов с необязательными фильтрами.

    Returns:
        dict: Объект с массивом items.
    """
    group_id = request.args.get("group_id", type=int)
    q = (request.args.get("q") or "").strip() or None
    return {"items": service.list_students(group_id, q)}


@bp.post("/api/students")
@bp.post("/api/students/<int:record_id>")
def save_item(record_id=None):
    """Читает JSON и вызывает сохранение студента.

    Args:
        record_id (int | None): ID из адреса при изменении.

    Returns:
        tuple: Объект item и статус 201 либо 200.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ValueError("Ожидается JSON-объект.")
    item = service.save_student(
        data.get("name"), data.get("group_id"), data.get("email"), record_id
    )
    return {"item": item}, 201 if record_id is None else 200


@bp.delete("/api/students/<int:record_id>")
def delete_item(record_id):
    """Вызывает удаление студента вместе с оценками.

    Args:
        record_id (int): ID из адреса.

    Returns:
        tuple: Пустое тело и статус 204.
    """
    service.delete_student(record_id)
    return "", 204
