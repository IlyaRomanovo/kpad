"""HTTP и JSON раздела reports. SQL находится в репозитории."""

from flask import request
from . import bp, service


@bp.get("/api/reports")
def get_report():
    """Возвращает выбранный отчёт.

    Returns:
        dict: Объект с kind и массивом items.
    """
    kind = request.args.get("kind", "")
    return {"kind": kind, "items": service.get_report(kind)}
