import {requestJSON} from "/static/js/api.js";
import {cell, message, busy, emptyRow} from "/static/js/ui.js";
const API = "/api/reports";
const head = document.querySelector("#table-head");
const body = document.querySelector("#table-body");
const kindSelect = document.querySelector("#report-kind");
const COLUMNS = {
  groups: [["name", "Группа", ""], ["student_count", "Студентов", "number"], ["grade_count", "Оценок", "number"], ["average_mark", "Средний балл", "number"]],
  no_grades: [["name", "Студент", ""], ["group_name", "Группа", ""]],
  failing: [["name", "Студент", ""], ["group_name", "Группа", ""]]
};

/** Строит таблицу выбранного отчёта. */
function render(kind, items) {
  head.replaceChildren(); body.replaceChildren();
  const columns = COLUMNS[kind];
  const headRow = document.createElement("tr");
  for (const column of columns) {
    const th = document.createElement("th"); th.textContent = column[1];
    if (column[2]) th.className = column[2];
    headRow.append(th);
  }
  head.append(headRow);
  if (!items.length) { emptyRow(body, columns.length); return; }
  for (const item of items) {
    const row = document.createElement("tr");
    for (const column of columns) row.append(cell(item[column[0]], column[2]));
    body.append(row);
  }
}

/** Загружает выбранный отчёт и выводит таблицу. */
async function load() {
  busy(true); message("Загрузка...");
  try {
    const data = await requestJSON(API + "?kind=" + kindSelect.value);
    render(data.kind, data.items); message();
  } catch (error) {
    head.replaceChildren(); emptyRow(body, 1, "Данные не загружены");
    message(error.message, true);
  } finally { busy(false); }
}

kindSelect.addEventListener("change", load);
load();
