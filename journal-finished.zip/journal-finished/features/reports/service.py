"""Выбор и выполнение SQL-отчётов раздела reports."""

from db import connect_db
from . import repo

REPORTS = {
    "groups": repo.group_report,
    "no_grades": repo.no_grades_report,
    "failing": repo.failing_report,
}


def get_report(kind):
    """Вызывает один из трёх отчётов по его имени.

    Args:
        kind (str): groups, no_grades либо failing.

    Returns:
        list[dict]: Строки отчёта по контракту.

    Raises:
        ValueError: Неизвестный вид отчёта.
    """
    if kind not in REPORTS:
        raise ValueError("Неизвестный вид отчёта.")
    con = connect_db()
    try:
        return REPORTS[kind](con)
    finally:
        con.close()
