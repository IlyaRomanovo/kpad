import {requestJSON} from "/static/js/api.js";
import {cell, message, busy, emptyRow, fillGroups} from "/static/js/ui.js";
const API = "/api/journal";
const head = document.querySelector("#table-head");
const body = document.querySelector("#table-body");
const editor = document.querySelector("#editor");
const form = document.querySelector("#edit-form");
const studentInput = document.querySelector("#grade-student");
const subjectInput = document.querySelector("#grade-subject");
const markSelect = document.querySelector("#grade-mark");
const deleteButton = document.querySelector("#delete-grade");
const groupSelect = document.querySelector("#group-select");
let journal = null, loaded = false;

/** Отправляет установку или изменение оценки. */
async function saveGrade(studentId, subjectId, mark) {
  return requestJSON(API + "/grades", "POST", {student_id: studentId, subject_id: subjectId, mark: mark});
}

/** Отправляет удаление оценки по паре студент и предмет. */
async function deleteGrade(studentId, subjectId) {
  return requestJSON(API + "/grades/" + studentId + "/" + subjectId, "DELETE");
}

/** Находит оценку пары в загруженном журнале. */
function findGrade(studentId, subjectId) {
  if (!journal) return null;
  const grade = journal.grades.find(function(item) {
    return item.student_id === studentId && item.subject_id === subjectId;
  });
  return grade || null;
}

/** Строит матрицу студентов и предметов. */
function render() {
  head.replaceChildren(); body.replaceChildren();
  if (!journal) return;
  const headRow = document.createElement("tr");
  const nameHead = document.createElement("th"); nameHead.textContent = "Студент";
  headRow.append(nameHead);
  for (const subject of journal.subjects) {
    const th = document.createElement("th"); th.textContent = subject.name; th.className = "grade-cell";
    headRow.append(th);
  }
  head.append(headRow);
  if (!journal.students.length) { emptyRow(body, journal.subjects.length + 1, "В группе нет студентов"); return; }
  for (const student of journal.students) {
    const row = document.createElement("tr"); row.append(cell(student.name));
    for (const subject of journal.subjects) {
      const grade = findGrade(student.id, subject.id);
      const td = document.createElement("td"); td.className = "grade-cell";
      const button = document.createElement("button"); button.type = "button";
      button.className = "grade-button";
      button.dataset.student = String(student.id); button.dataset.subject = String(subject.id);
      if (grade) {
        button.textContent = String(grade.mark);
        button.dataset.mark = String(grade.mark);
        if (grade.mark === 2) button.classList.add("failing");
      } else {
        button.textContent = "—"; button.classList.add("empty");
      }
      td.append(button); row.append(td);
    }
    body.append(row);
  }
}

/** Загружает журнал выбранной группы без перезагрузки страницы. */
async function load(groupId, successText = "") {
  busy(true); message("Загрузка...");
  try { journal = await requestJSON(API + "?group_id=" + groupId); loaded = true; render(); message(successText); }
  catch (error) {
    message((successText ? successText + " Обновление журнала не удалось. " : "") + error.message, true);
    if (!loaded) { head.replaceChildren(); emptyRow(body, 1, "Данные не загружены"); }
  } finally { busy(false); }
}

/** Загружает список групп и открывает первую из них. */
async function loadGroups() {
  try {
    const groups = (await requestJSON("/api/groups")).items;
    fillGroups(groupSelect, groups);
    if (groupSelect.value) await load(Number(groupSelect.value));
  } catch (error) { message(error.message, true); }
}

groupSelect.addEventListener("change", function() {
  editor.hidden = true; message();
  if (groupSelect.value) load(Number(groupSelect.value));
});

body.addEventListener("click", function(event) {
  const button = event.target.closest("button[data-student]"); if (!button || !journal) return;
  const student = journal.students.find(function(item) { return item.id === Number(button.dataset.student); });
  const subject = journal.subjects.find(function(item) { return item.id === Number(button.dataset.subject); });
  if (!student || !subject) return;
  form.reset();
  studentInput.value = button.dataset.student; subjectInput.value = button.dataset.subject;
  markSelect.value = button.dataset.mark || "";
  deleteButton.hidden = !button.dataset.mark;
  document.querySelector("#editor-title").textContent = student.name + " — " + subject.name;
  editor.hidden = false; message(); markSelect.focus();
});

document.querySelector("#cancel-edit").addEventListener("click", function() { editor.hidden = true; message(); });

form.addEventListener("submit", async function(event) {
  event.preventDefault();
  if (!markSelect.value) { message("Выберите оценку.", true); markSelect.focus(); return; }
  busy(true);
  try {
    await saveGrade(Number(studentInput.value), Number(subjectInput.value), Number(markSelect.value));
    editor.hidden = true; form.reset(); await load(Number(groupSelect.value), "Оценка сохранена.");
  } catch (error) { message(error.message, true); }
  finally { busy(false); }
});

deleteButton.addEventListener("click", async function() {
  busy(true);
  try {
    await deleteGrade(Number(studentInput.value), Number(subjectInput.value));
    editor.hidden = true; form.reset(); await load(Number(groupSelect.value), "Оценка удалена.");
  } catch (error) { message(error.message, true); }
  finally { busy(false); }
});

loadGroups();
