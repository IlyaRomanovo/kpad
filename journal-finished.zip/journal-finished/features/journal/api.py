"""HTTP и JSON раздела journal. SQL и бизнес-правила находятся ниже."""

from flask import request
from . import bp, service


@bp.get("/api/journal")
def get_journal():
    """Возвращает данные журнала выбранной группы.

    Returns:
        dict: Объект с group, students, subjects и grades.
    """
    group_id = request.args.get("group_id", type=int)
    if group_id is None:
        raise ValueError("Укажите группу.")
    return service.get_journal(group_id)


@bp.post("/api/journal/grades")
def save_item():
    """Читает JSON и вызывает установку либо изменение оценки.

    Returns:
        tuple: Объект item и статус 200.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ValueError("Ожидается JSON-объект.")
    item = service.save_grade(
        data.get("student_id"), data.get("subject_id"), data.get("mark")
    )
    return {"item": item}, 200


@bp.delete("/api/journal/grades/<int:student_id>/<int:subject_id>")
def delete_item(student_id, subject_id):
    """Вызывает удаление оценки по паре студент и предмет.

    Args:
        student_id (int): ID студента из адреса.
        subject_id (int): ID предмета из адреса.

    Returns:
        tuple: Пустое тело и статус 204.
    """
    service.delete_grade(student_id, subject_id)
    return "", 204
