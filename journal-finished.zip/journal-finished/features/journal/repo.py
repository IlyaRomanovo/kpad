"""SQL раздела journal. Соединение передаёт сервис, commit здесь отсутствует."""

def get_group(con, group_id):
    """Находит группу по идентификатору.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM groups WHERE id = ?
        ''',
        (group_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def list_students(con, group_id):
    """Возвращает всех студентов выбранной группы.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Значение параметра запроса.

    Returns:
        list[dict]: Строки с id и name.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM students WHERE group_id = ? ORDER BY name, id
        ''',
        (group_id,),
    )
    return [dict(row) for row in cursor.fetchall()]


def list_subjects(con):
    """Возвращает общие предметы для столбцов журнала.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.

    Returns:
        list[dict]: Строки с id и name.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM subjects ORDER BY name, id
        ''',
        (),
    )
    return [dict(row) for row in cursor.fetchall()]


def list_grades(con, group_id):
    """Возвращает оценки студентов выбранной группы.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        group_id: Значение параметра запроса.

    Returns:
        list[dict]: Строки с id, student_id, subject_id и mark.
    """
    cursor = con.execute(
        '''
        SELECT gr.id, gr.student_id, gr.subject_id, gr.mark
        FROM grades AS gr
        JOIN students AS s ON s.id = gr.student_id
        WHERE s.group_id = ?
        ORDER BY gr.student_id, gr.subject_id
        ''',
        (group_id,),
    )
    return [dict(row) for row in cursor.fetchall()]


def get_grade(con, student_id, subject_id):
    """Находит оценку по паре студент и предмет.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.
        subject_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, student_id, subject_id, mark
        FROM grades WHERE student_id = ? AND subject_id = ?
        ''',
        (student_id, subject_id),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_student(con, student_id):
    """Находит студента по идентификатору.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, name, group_id FROM students WHERE id = ?
        ''',
        (student_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def get_subject(con, subject_id):
    """Находит предмет по идентификатору.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        subject_id: Значение параметра запроса.

    Returns:
        dict | None: Запись либо None.
    """
    cursor = con.execute(
        '''
        SELECT id, name FROM subjects WHERE id = ?
        ''',
        (subject_id,),
    )
    row = cursor.fetchone()
    return dict(row) if row is not None else None


def insert_grade(con, student_id, subject_id, mark):
    """Добавляет оценку без фиксации транзакции.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.
        subject_id: Значение параметра запроса.
        mark: Значение оценки от 2 до 5.

    Returns:
        int: Идентификатор новой записи.
    """
    cursor = con.execute(
        '''
        INSERT INTO grades (student_id, subject_id, mark) VALUES (?, ?, ?)
        ''',
        (student_id, subject_id, mark),
    )
    return cursor.lastrowid


def update_grade(con, mark, student_id, subject_id):
    """Изменяет существующую оценку пары студент и предмет.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        mark: Новое значение оценки от 2 до 5.
        student_id: Значение параметра запроса.
        subject_id: Значение параметра запроса.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        UPDATE grades SET mark = ? WHERE student_id = ? AND subject_id = ?
        ''',
        (mark, student_id, subject_id),
    )


def delete_grade(con, student_id, subject_id):
    """Удаляет оценку; отсутствие строки не является ошибкой.

    Args:
        con (sqlite3.Connection): Соединение текущей операции.
        student_id: Значение параметра запроса.
        subject_id: Значение параметра запроса.

    Returns:
        None: Изменения остаются в текущей транзакции.
    """
    cursor = con.execute(
        '''
        DELETE FROM grades WHERE student_id = ? AND subject_id = ?
        ''',
        (student_id, subject_id),
    )
