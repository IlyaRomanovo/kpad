"""Бизнес-правила и транзакции раздела journal."""

from db import connect_db
from . import repo

ALLOWED_MARKS = (2, 3, 4, 5)


def _check_positive_id(value, label):
    """Проверяет положительный целочисленный идентификатор.

    Args:
        value: Значение из JSON-запроса или адреса.
        label (str): Название поля для сообщения.

    Returns:
        None: Проверка пройдена.

    Raises:
        ValueError: Значение не является положительным целым.
    """
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("Некорректный идентификатор: " + label + ".")


def get_journal(group_id):
    """Возвращает группу, студентов, предметы и оценки группы.

    Args:
        group_id (int): Идентификатор группы из параметра запроса.

    Returns:
        dict: Объект group, students, subjects и grades.

    Raises:
        ValueError: Идентификатор группы некорректен.
        LookupError: Группа отсутствует.
    """
    _check_positive_id(group_id, "group_id")
    con = connect_db()
    try:
        group = repo.get_group(con, group_id)
        if group is None:
            raise LookupError("Группа не найдена.")
        return {
            "group": group,
            "students": repo.list_students(con, group_id),
            "subjects": repo.list_subjects(con),
            "grades": repo.list_grades(con, group_id),
        }
    finally:
        con.close()


def save_grade(student_id, subject_id, mark):
    """Устанавливает или изменяет итоговую оценку одной транзакцией.

    Args:
        student_id (int): Идентификатор студента.
        subject_id (int): Идентификатор предмета.
        mark (int): Оценка из набора 2, 3, 4, 5.

    Returns:
        dict: Запись оценки с id, student_id, subject_id и mark.

    Raises:
        ValueError: Идентификаторы или оценка некорректны.
        LookupError: Студент либо предмет отсутствует.
    """
    _check_positive_id(student_id, "student_id")
    _check_positive_id(subject_id, "subject_id")
    if isinstance(mark, bool) or not isinstance(mark, int) or mark not in ALLOWED_MARKS:
        raise ValueError("Оценка должна быть целым числом 2, 3, 4 или 5.")
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, student_id) is None:
                raise LookupError("Студент не найден.")
            if repo.get_subject(con, subject_id) is None:
                raise LookupError("Предмет не найден.")
            if repo.get_grade(con, student_id, subject_id) is None:
                repo.insert_grade(con, student_id, subject_id, mark)
            else:
                repo.update_grade(con, mark, student_id, subject_id)
            result = repo.get_grade(con, student_id, subject_id)
        return result
    finally:
        con.close()


def delete_grade(student_id, subject_id):
    """Удаляет оценку, сохраняя родительские записи.

    Args:
        student_id (int): Идентификатор студента.
        subject_id (int): Идентификатор предмета.

    Returns:
        None: Транзакция завершена; пустая ячейка допустима.

    Raises:
        ValueError: Идентификаторы некорректны.
        LookupError: Студент либо предмет отсутствует.
    """
    _check_positive_id(student_id, "student_id")
    _check_positive_id(subject_id, "subject_id")
    con = connect_db()
    try:
        with con:
            if repo.get_student(con, student_id) is None:
                raise LookupError("Студент не найден.")
            if repo.get_subject(con, subject_id) is None:
                raise LookupError("Предмет не найден.")
            repo.delete_grade(con, student_id, subject_id)
    finally:
        con.close()
